#encoding:utf-8
require 'rubygems'
require 'rest_client'
require 'json' 

# set function url
request_url = 'http://127.0.0.1:3000/sf1/search_by_image'

# set function parameters
search_request = {
    "collection" => "test_doc",
    "similar_to_image" => "http://img.izenesoft.cn/200K?p=2",
    "select" => [
        "Title", 
        { "property" => "Content", "highlight" => "false", "snippet" => "false", "summary" => "false", "summary_sentence_count" => 2, "summary_property_alias" => "Content.summary" }
    ],
    "limit" => 10,
    "offset" => 0,
    "remove_duplicate_result" => "false"
}

# send http request to function url by rest client
# please insure to set "content_type" and "accept" 
#   "content_type" means the http body content type,  the http body is "search_request.to_json" 
#   "accept" represents for the result format, you can also set it to "xml" or "js" to get related format result
 
res = RestClient.post request_url, search_request.to_json, :content_type => :json, :accept => :json

p res

