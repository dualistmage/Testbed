#encoding:utf-8
require 'rubygems'
require 'rest_client'
require 'json' 

# set function url
request_url = 'http://211.39.140.118:3000/sf1/search_by_keywords'

# set function parameters
search_request = {
    "collection" => "korean-news",
    "search" => {
        "keywords" => "자동차",
        "in" => ["Title", "Content"],
        "log_keyword" => "true",
        "analyzer" => {
            "apply_la" => "true",
            "use_synonym_extention" => "false",
            "use_original_keyword" => "false"
        }
    },
    "conditions" => [
        #{"property" => "Title", "operator" => "=", "value" => "Test"}
    ],
    "select" => [
        "Title", 
        { "property" => "Content", "highlight" => "false", "snippet" => "false", "summary" => "true", "summary_sentence_count" => 2}
    ],
    "sort" => [
        #{"property" => "Title", "order" => "ACS"},
        #{"property" => "Content"}
    ],
    "limit" => 10,
    "offset" => 0,
    "remove_duplicate_result" => "false"
}

# send http request to function url by rest client
# please insure to set "content_type" and "accept" 
#   "content_type" means the http body content type,  the http body is "search_request.to_json" 
#   "accept" represents for the result format, you can also set it to "xml" or "js" to get related format result
 
res = RestClient.post request_url, search_request.to_json, :content_type => :json, :accept => :json

resultVal = JSON.parse(res)

resultVal = JSON.parse(res)ultVal['name_entity'][0]['type']
p resultVal
