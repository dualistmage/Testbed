#encoding:utf-8
require 'rubygems'
require 'rest_client'
require 'json' 

# set function url
request_url = 'http://127.0.0.1:3000/sf1/delete_doc'

# set function parameters
search_request = {
    "collection" => "test_doc",
    "resource" => {
        "DOCID" => "20101010101-01",
    }
    
}

# send http request to function url by rest client
# please insure to set "content_type" and "accept" 
#   "content_type" means the http body content type,  the http body is "search_request.to_json" 
#   "accept" represents for the result format, you can also set it to "xml" or "js" to get related format result
 
res = RestClient.post request_url, search_request.to_json, :content_type => :json, :accept => :json

resultVal = JSON.parse(res)

p resultVal
